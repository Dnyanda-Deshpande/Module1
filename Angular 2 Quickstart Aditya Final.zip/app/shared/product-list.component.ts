
import {Component, OnInit} from 'angular2/core';
import {IProduct} from './product';
import {ProductFilterPipe} from  './product-filter.pipe';
import {StarComponent} from '../shared/star.component';

@Component(
{
    selector : 'pm-products',
    templateUrl:'app/products/product-list.component.html',
    styleUrls:['app/products/product-list.component.css'] ,
    pipes:[ProductFilterPipe],
    directives:[StarComponent]
})

export class ProductListComponent implements OnInit
{
  pageTitle:string="Acme Project Management";
     listFilter:string='';
  ngOnInit():void
  {
   
    console.log("On init fired!!!");
  }
   products: IProduct[] = [
 
        {
            "productId": 2,
            "productName": "Garden Cart",
            "productCode": "GDN-0023",
            "releaseDate": "March 18, 2016",
            "description": "15 gallon capacity rolling garden cart",
            "price": 32.99,
            "starRating": 4.2,
            "imageUrl": "https://www.gstatic.com/webp/gallery3/1.png"
        },
        {
            "productId": 5,
            "productName": "Hammer",
            "productCode": "TBX-0048",
            "releaseDate": "May 21, 2016",
            "description": "Curved claw steel hammer",
            "price": 8.9,
            "starRating": 4.8,
            "imageUrl": "https://www.gstatic.com/webp/gallery3/2.png"
        }
    ];


    imageWidth:number = 70;
    imageMargin:number = 20;

    showImage:boolean = false;

    toggleImage():void
    {
      this.showImage =! this.showImage;
    }


    onRatingClicked(meassage:string):void
    {
        this.pageTitle = 'Product List : '+meassage;
    }


 
}
