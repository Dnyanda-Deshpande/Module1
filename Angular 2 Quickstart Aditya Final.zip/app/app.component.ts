import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core';
import {ProductListComponent} from './products/product-list.component';
import {Router} from 'angular2/router';

@Component(
{
    selector : 'pm-app',
    template:   `<pm-products></pm-products>
        <h1>Angular Router</h1>
    <nav>
      <a routerLink="/click-center" routerLinkActive="active">Click Here</a>
    
    </nav>
    <router-outlet></router-outlet>
  `,
    directives:[ProductListComponent]
})

export class AppComponent 
{
 

}
