import {Component} from 'angular2/core';

@Component(
{
    selector : 'load-link'
})


export class LinkComponet 
{
    
}