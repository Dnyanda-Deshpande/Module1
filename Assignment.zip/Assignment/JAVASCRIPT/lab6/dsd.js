function invoice()
					{

						var barbie=document.getElementById('qtyTxtId').value;
						var calcu=document.getElementById('calTxtId').value;
						var mob=document.getElementById('mobTxtId').value;
						var dvd=document.getElementById('dvdTxtId').value;
						var t1=0,t2=0,t3=0,t4=0;
						
						if(barbie==''&&calcu==''&&mob==''&&dvd=='')
						{
							alert("no item is selected");
						}
						else
						{
							if(barbie!='')
							{
								t1=20*barbie;
							}
							if(calcu!='')
							{
								t2=30*calcu;
							}
							if(mob!='')
							{
								t3=40*mob;
							}
							if(dvd!='')
							{
								t4=50*dvd;
							}
							
							var myWindow=window.open("","INVOICE","height=500,width=500,top=400,left=200");
							myWindow.document.write("<h2 align=center>INVOICE</h2>");
							myWindow.document.write("<table border=1 cellspacing=5 cellpadding=6><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th></tr>");
							if(t1!=0)
							{
								myWindow.document.write("<tr><td>Barbie Doll</td><td>"+barbie+"</td><td>20</td><td>"+t1+"</td></tr>");
							}
							if(t2!=0)
							{
								myWindow.document.write("<tr><td>Calculator</td><td>"+calcu+"</td><td>30</td><td>"+t2+"</td></tr>");
							}
							if(t3!=0)
							{
								myWindow.document.write("<tr><td>Mobile Phone</td><td>"+mob+"</td><td>40</td><td>"+t3+"</td></tr>");
							}
							if(t4!=0)
							{
								myWindow.document.write("<tr><td>LG DVD</td><td>"+dvd+"</td><td>50</td><td>"+t4+"</td></tr>");
							}
						}
						
						     
					}
