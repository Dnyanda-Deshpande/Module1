function invoice()
{

	var barbie=document.getElementById('qtyTxtId').value;

	
	var calcu=document.getElementById('calTxtId').value;

	
	var mob=document.getElementById('mobTxtId').value;


	var dvd=document.getElementById('dvdTxtId').value;
	
	
	
	
	if(barbie==''&&calcu==''&&mob==''&&dvd=='')
	{
		alert("no item is selected");
	}
	
	     
}
