function showCategory()
{
	var obj=window.document.myFrm.category;
	var category=new Array("Electronics","Grocery");
	for(var i=0;i<category.length;i++)
	{
		obj.options[i]=new Option(category[i],category[i]);
	}
}

function displayList()
{
	var categoeyObj=window.document.myFrm.category;
	var productObj=window.document.myFrm.product;
	var catSelectedIndex=categoeyObj.selectedIndex;
	var products=new Array();
	products[0]=new Array("Television","Laptop","Phone");
	products[1]=new Array("Soap","Powder");
	for(var i=0;i<products[catSelectedIndex].length;i++)
	{
		productObj.options[i]=new Option(products[catSelectedIndex][i],products[catSelectedIndex][i]);
	}
}


function priceT()
{
	var categoeyObj=window.document.myFrm.category;
	var productObj=window.document.myFrm.product;
	var CategoryIndex=categoeyObj.selectedIndex;
	var productIndex=productObj.selectedIndex;
	var result;
	var quantity=document.getElementById("qtyId").value;
	if(CategoryIndex==0 && productIndex==0)
	{
		result=200000*quantity;
	}
	if(CategoryIndex==0 && productIndex==1)
	{
		result=300000*quantity;
	}
	if(CategoryIndex==0 && productIndex==2)
	{
		result=100000*quantity;
	}
	if(CategoryIndex==1 && productIndex==0)
	{
		result=40*quantity;
	}
	if(CategoryIndex==1 && productIndex==1)
	{
		result=90*quantity;
	}
	document.getElementById("priceId").value=result;
}



