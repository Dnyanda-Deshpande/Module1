var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";

function addNos(headVar,bodyVar)
{

//TODO: display the contents of the variable "msg" 
document.write(msg);
//TODO: display the addition of two numbers
document.write("The sum of variables headVar and bodyVar is "+(headVar+bodyVar));
}
