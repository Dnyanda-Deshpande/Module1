class BasicPhone extends Mobile
		{
			constructor(mobileId,mobileName,mobileCost,mobileType)
			{
				super(mobileId,mobileName,mobileCost);
				this.mobileType=mobileType;
				
			}
			
			printMobileDetails()
			{
				super.printMobileDetails();
				console.log("Mobile Type : "+this.mobileType);
				
			}
		}
		
			
		var mobo = new BasicPhone(1001,"Moto",100000,"Basic");
		console.log(mobo.printMobileDetails());
		
		
		
	
		