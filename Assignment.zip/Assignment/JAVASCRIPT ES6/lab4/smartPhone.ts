class SmartPhone extends Mobile
		{
			constructor(mobileId,mobileName,mobileCost,mobileType)
			{
				super(mobileId,mobileName,mobileCost);
				this.mobileType=mobileType;
				
			}
			
			printMobileDetails()
			{
				super.printMobileDetails();
				console.log("Mobile Type : "+this.mobileType);
				
			}
		}
		
	 
	var mob = new SmartPhone(1002,"Lenovo",13400,"Smart");
		console.log(mob.printMobileDetails());