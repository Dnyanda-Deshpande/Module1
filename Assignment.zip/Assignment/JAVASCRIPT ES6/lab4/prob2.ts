import {BasicPhone} from './basicPhone';


class Mobile
		{
		
			constructor(mobileId,mobileName,mobileCost)
			{
				
				this.mobileId = mobileId;
				this.mobileName = mobileName;
				this.mobileCost = mobileCost;
				
			}
			
			
			
			printMobileDetails()
			{
				
				console.log("Mobile Id :" +this.mobileId+"\nMobile Name :" +this.mobileName+ "\nMobile Cost : "+this.mobileCost);
			}
		}
		
		