
import {Product} from './product';


export const PRODUCTS : Product[]=[
    {
        productId: 11,
        productName: 'Electronics',
         imageUrl : 'https://mibgadgets.com/wp-content/uploads/2017/08/pexels-photo-325153.jpeg',
         pagedisplay: 'electronics'
    },
     {
        productId: 12,
        productName: 'Clothing',
         imageUrl : 'https://thumb7.shutterstock.com/display_pic_with_logo/3106751/1044580621/stock-photo-soft-focus-of-a-two-years-old-child-choosing-her-own-dresses-from-kids-cloth-rack-1044580621.jpg',

         pagedisplay:'clothing'
     },
    {
        productId: 13,
        productName: 'Grocery',
         imageUrl : 'https://retaileconomics.com/wp-content/uploads/2015/11/online-grocery-shopping-pc.jpg',
         pagedisplay:'grocery'
    },
    {
        productId: 14,
        productName: 'Footwear',
         imageUrl : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQjYLy36e9nghoFV93rCOO8gvfVyyJscAr4w6bDDnqkNtuFMXodqA',
         pagedisplay:'footwear'
    },
 

]






