import { Component, OnInit } from '@angular/core';
import {DisplayProductService} from '../display-product.service';
@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {

    message:any;
    price: number =0;
     data2:any
  constructor(private data: DisplayProductService ) { }

  ngOnInit() {
       this.data.MyMessage.subscribe(message => this.message = message)
       console.log(this.message);
        this.calculateBill();
     
  }
  calculateBill()
  {
     console.log("giijijsd");
      this.data2=  Array.from(this.message.keys());
    
       console.log(this.data2);
  }

}
